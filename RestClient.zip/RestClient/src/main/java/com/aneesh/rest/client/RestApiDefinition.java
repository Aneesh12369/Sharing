package com.aneesh.rest.client;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class RestApiDefinition {

	private String name;

	private boolean enabled = true;

	private String baseUrl;

	private Map<String, RestCallDefinition> restCalls = new HashMap<>();

}