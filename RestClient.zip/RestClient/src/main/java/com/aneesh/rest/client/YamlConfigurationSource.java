package com.aneesh.rest.client;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;

public class YamlConfigurationSource<T> implements ConfigurationSource<T> {
	
	private static final String DEFAULT_PATH = "rest-apis";

	private final Registry<T> registry;
	private final YamlReader<T> yamlReader;

	public YamlConfigurationSource(Registry<T> registry, YamlReader<T> yamlReader) {
		this.registry = registry;
		this.yamlReader = yamlReader;
	}

	@Override
	public void loadAndRegister() {

		URL resource = this.getClass().getClassLoader().getResource(DEFAULT_PATH);
		if (resource != null) {
			try {
				Files.walk(Paths.get(resource.toURI()))
						.filter(Files::isRegularFile)
						.map(path -> DEFAULT_PATH +"/"+ path.getFileName().toString())
						.map(yamlReader::readClassPathFile)
						.flatMap(list -> list.stream())
						.forEach(def -> {
							registry.register(def);
						});
						
			} catch (Exception e) {
				throw new RuntimeException("unable to load yaml resources");
			}
		} else {
			System.out.println("empty");
		}

	}

}
