package com.aneesh.rest.client;

public interface ConfigurationSource<T> {

	void loadAndRegister();
	

}
