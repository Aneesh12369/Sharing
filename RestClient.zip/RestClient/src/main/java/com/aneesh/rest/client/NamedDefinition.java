package com.aneesh.rest.client;

/**
 * An optional interface definitions can implement to signify their name is configurable.
 */
public interface NamedDefinition {
    String getName();
}
