package com.aneesh.rest.client;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class RestApiRegistry implements Registry<RestApiDefinition> {

	private final Map<String, RestApiDefinition> registryMap = new HashMap<>();

	@Override
	public void register(RestApiDefinition def) {
		if (def.isEnabled()) {
			registryMap.put(def.getName(), def);
		}

	}

	@Override
	public void unRegister(RestApiDefinition def) {
		registryMap.remove(def.getName());

	}

	@Override
	public Collection<RestApiDefinition> getAllDefinitions() {
		return registryMap.values();
	}

}
