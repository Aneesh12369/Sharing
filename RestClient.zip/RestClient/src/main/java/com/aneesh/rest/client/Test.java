package com.aneesh.rest.client;

public class Test {

	public static void main(String[] args) {
		/*YamlReader<RestApiDefinition> reader = new YamlReader<>(RestApiDefinition.class);
		List<RestApiDefinition> restApiDefinition = reader.readClassPathFile("test_api.yaml");
		
		for (RestApiDefinition _2 : restApiDefinition) {
			System.out.println(_2);
		}
		*/
		
		Registry<RestApiDefinition> registry = new RestApiRegistry();
		YamlReader<RestApiDefinition> reader = new YamlReader<>(RestApiDefinition.class);
		
		
		ConfigurationSource<RestApiDefinition> yamlConfigSource = new YamlConfigurationSource<>(registry, reader);
		yamlConfigSource.loadAndRegister();
		registry.getAllDefinitions().forEach(System.out::println);
		
		

	}

}

