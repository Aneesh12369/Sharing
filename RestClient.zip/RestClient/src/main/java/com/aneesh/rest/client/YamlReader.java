package com.aneesh.rest.client;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import org.yaml.snakeyaml.representer.Representer;

public class YamlReader<T> {

	private Yaml yaml;
	private Class<T> clazz;

	public YamlReader(Class<T> clazz) {
		this.clazz = clazz;
		Representer representer = new Representer(new DumperOptions());
		representer.getPropertyUtils().setSkipMissingProperties(true);
		Constructor constructor = new Constructor(clazz, new LoaderOptions());
		this.yaml = new Yaml(constructor, representer);
	}

	public List<T> readClassPathFile(String file) {
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(file);
		Iterable<Object> docs = yaml.loadAll(inputStream);
		List<T> list = new ArrayList<>();
		for (Object obj : docs) {
			if (this.clazz.isAssignableFrom(obj.getClass())) {
				list.add((T)obj);
			}
		}
		return list;
	}

}
