package com.aneesh.rest.client;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class RestCallDefinition {
	private String method;
	private String path;
	private String entityType = "java.lang.String";
	private String responseContentType;
	private Map<String, String> queryParameters = new HashMap<>();
	private Map<String, Object> headers = new HashMap<>();
	private Map<String, Object> defaultValues = new HashMap<>();
	private Object body;
	private String securityScheme;

}
