package com.aneesh.rest.client;

import java.util.Collection;

public interface Registry<T> {

	void register(T t);

	void unRegister(T t);

	Collection<T> getAllDefinitions();

}
